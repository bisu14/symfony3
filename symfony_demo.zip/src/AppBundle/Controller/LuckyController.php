<?php

// src/Controller/LuckyController.php
namespace AppBundle\Controller;

use Symfony\Component\HttpFoundation\Response;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\Routing\Route;
use Symfony\Component\Routing\RouteCollection;

class LuckyController extends Controller
{
    public function numberAction()
    {
        $number = mt_rand(0, 100);


          return $this->render(
            'default/lucky.html.twig',
            array('number' => $number)
        );

       

       /* return new Response(
            '<html><body>Lucky number: '.$number.'</body></html>'
        );*/
    }
}