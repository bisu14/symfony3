<?php
// src/AppBundle/Controller/RegistrationController.php
namespace AppBundle\Controller;

use AppBundle\Form\UserType;
use AppBundle\Form\UsearchType;
use AppBundle\Entity\User;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Route;
use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\Security\Core\Encoder\UserPasswordEncoderInterface;
use AppBundle\Service\FileUploader;

class RegistrationController extends Controller
{
    /**
     * @Route("/register", name="user_registration")
     */
    public function registerAction(Request $request, UserPasswordEncoderInterface $passwordEncoder,FileUploader $fileUploader)
    {



        // 1) build the form
        $user = new User();
        $form = $this->createForm(UserType::class, $user);

        // 2) handle the submit (will only happen on POST)
        $form->handleRequest($request);
        if ($form->isSubmitted() && $form->isValid()) {

            // 3) Encode the password (you could also do this via Doctrine listener)
            $password = $passwordEncoder->encodePassword($user, $user->getPlainPassword());
            $user->setPassword($password);



             $file = $user->getVcard();

            // Generate a unique name for the file before saving it
            $fileName = md5(uniqid()).'.'.$file->guessExtension();

            // Move the file to the directory where brochures are stored
            $file->move(
                $this->getParameter('vcard_directory'),
                $fileName
            );




            // Update the 'brochure' property to store the PDF file name
            // instead of its contents
            $user->setvcard($fileName);

            // 4) save the User!
            $em = $this->getDoctrine()->getManager();
            $em->persist($user);
            $em->flush();

            // ... do any other work - like sending them an email, etc
            // maybe set a "flash" success message for the user
              //return $this->redirect($this->generateUrl('login'));
            //return $this->redirectToRoute('/login');

          // return $this->redirectToRoute('login');
           return $this->redirect('login');
            //return $this->redirect('www.google.com', 301);

        }

        return $this->render(
            'registration/register.html.twig',
            array('form' => $form->createView())
        );
    }

    public function geAlluserAction()
    {

        $repository = $this->getDoctrine()
        ->getRepository(User::class);
        $users = $repository->findAll();
       // print_r($users);
       return $this->render(
            'registration/userdata.html.twig',
            array('users_data' => $users)
        );



    }



     public function contactAction(Request $request)
    {
        // Create the form according to the FormType created previously.
        // And give the proper parameters
        $form = $this->createForm('AppBundle\Form\ContactType',null,array(
            // To set the action use $this->generateUrl('route_identifier')
            'action' => $this->generateUrl('appbundle_contact'),
            'method' => 'POST'
        ));

        if ($request->isMethod('POST')) {
            // Refill the fields in case the form is not valid.
            $form->handleRequest($request);

            if($form->isValid()){
                
                    $this->addFlash("success", "Contact from submited successfully.");

                    return $this->redirect('contact');
                }else{
                    // An error ocurred, handle
                    var_dump("Errooooor :(");
                }
            //}
        }

        return $this->render('contact/contact.html.twig', array(
            'form' => $form->createView()
        ));
    }


}